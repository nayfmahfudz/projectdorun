// import 'package:flutter/material.dart';
// import 'package:main/model/apirequest.dart';
// class Present extends StatefulWidget {
//   @override
//   _PresentState createState() => _PresentState();
// }

// class _PresentState extends State<Present> {
//   Present(this.model)
//   Model model;
//   var finaldate;
//   void callDatePicker() async {
//     var order = await model.getDate();
//     setState(() {
//       finaldate = order;
//     });
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Container(
      
//     );
//   }
// }
  