import 'package:flutter/material.dart';


class Trackingrun extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child:Text("Peta Belum Tersedia",textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 40),)
    );
  }
}