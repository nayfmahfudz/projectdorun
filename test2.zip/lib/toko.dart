import 'package:flutter/material.dart';

class Toko extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("Toko masih kosong",textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 40),),
      
    );
  }
}