import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'model/User.dart';
import 'dart:async';
import 'User.dart';
import 'model/apirequest.dart'as api;


// final Restapi api;
// String url = "https://klomee.gempikoe.co.id/public/api/login/login?X-API-KEY=doran_data";
BuildContext context;
var emailcontroller=new TextEditingController();
var passcontroller=new TextEditingController();
var emailinputcontroller=new TextEditingController();
var passinputcontroller=new TextEditingController();
String msg='';



  //  jsondata.add(api);
  //   if(api == null)
  // {
  //    print("Login Gagal");
     
  // }else{
  //   // Navigator.pushNamed(context,'/Beranda');
  //    print("Login Gagal");


//     // If Email or Password did not Matched.
//     // Hiding the CircularProgressIndicator.
//     setState(() {
//       visible = false; 
//       });
// }
// }