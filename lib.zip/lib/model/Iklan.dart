import 'package:flutter/material.dart';



class Berita {
  Berita({this.id,this.tanggal_awal,this.tanggal_akhir,this.image,this.image,this.caption,this.url,});
  int id;
  String tanggal_awal;
  String tanggal_akhir;
  String image;
  String url;
  String caption;
  



    
    // String toString() {
    // return 'User{nama: $nama, id: $id,password: $password ,email: $email , image:$image, alamat: $alamat ,telpon: $telpon , pemilik: $pemilik}';}  
  factory Berita.fromJson(Map<String, dynamic> json) {
    return Berita(
      id : json["id"],
      tanggal_awal: json["tanggal_awal"],
      tanggal_akhir: json["tanggal_akhir"],
      url : json["url"],
      image: json["image"],
      caption : json["caption"],
      
    );
  }}   