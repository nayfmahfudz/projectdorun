import 'package:flutter/material.dart';
import 'package:test2/home.dart';
import 'package:test2/model/User.dart';
import 'package:test2/model/berita.dart';
import 'package:test2/provider/Restapi.dart' ;
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:test2/Appstate.dart';
import 'package:test2/main.dart';
import 'package:flutter/foundation.dart';


final restapi = Provider.of<Restapi>(context,listen: false);
// final restapi =
  // Future<List<Loginapi>> getuser(BuildContext context) async{ 
  // String url = "https://klomee.gempikoe.co.id/public/api/login/login?X-API-KEY=doran_data";
  // final response = await http.post(url,body: {"email": emailcontroller.text , "password": passcontroller.text,"kode_apk":"id.doran.klomee"}); 
  // final res = json.decode(response.body);
  //   List<Loginapi> data =[];
  // final api = Loginapi.fromJson(res);
  //    data.add(api);
  
     
  //     (res['result'] == true )? Navigator.pushNamed(context,'/Beranda') :  print("login gagal") ;
  //     data=setlistlogin;
      
  //  return setlistlogin;
   
   
   
  //  }
//  Future<Berita> getberita() async{ 
//   final url1 = "https://eclub.bukujurnal.com/api/berita?X-API-KEY=doran_data";
//   final response = await http.get(url1); 
//   final  res = json.decode(response.body);
//   // List<Berita> list =[];
//   return Berita.fromJson(res);
  // List<Berita> list = (json.decode(response.body) as List)
  //         .map((data) => new Berita.fromJson(data))
  //         .toList();
  // print(list);

    //  restapi.setdetailuser(User.fromJson(res["profile"]));

     
      // (res['result'] == true )? Navigator.pushNamed(context,'/Beranda') :  print("login gagal") ;
      // data=setlistlogin;
      // for (int i = 0; i <= res.length; i++){
      //   // restapi.setberitauser(list[i]);
      //    var post = Berita.fromJson(res);
      //   // print(restapi.getberitauser());
      //   list.add(post);
      //   // restapi.setberitauser(list);
      //   // return list;
      //   // print(restapi.beritas);
          
      // }
      //  return restapi.beritas ;
      
//  }


 Future <List> getberita() async{ 
  final url1 = "https://eclub.bukujurnal.com/api/berita?X-API-KEY=doran_data";
  final response = await http.get(url1); 
  // final res = json.decode(response.body);
  // List<Berita> list = [];
  List<Berita> list = (json.decode(response.body) as List)
          .map((data) => new Berita.fromJson(data))
          .toList();
  // final map = Berita.fromJson(res);
  // list.add(map);
  restapi.setberitauser(list);

  }

  // list.add(res);
    // return  Berita.fromJson(res);
    

    //  restapi.setdetailuser(User.fromJson(res["profile"]));

     
      // (res['result'] == true )? Navigator.pushNamed(context,'/Beranda') :  print("login gagal") ;
      // data=setlistlogin;
      // for (int i = 0; i <= 5; i++)
      // {
      //   if (response.statusCode == 200) {
      // list = (json.decode(response.body) as List)
      //     .map((data) => new Berita.fromJson(data))
      //     .toList();
      // setState(() {
      //   isLoading = false;
      // });
    // } else {
    //   throw Exception('Failed to load photos');
        
    //       // Berita.fromJson(res[]));
    //     // print(restapi.getberitauser());
          
      // }
      // restapi.setberitauser(list);
 
  
  
  Future getuser(BuildContext context) async{ 
  final url = "https://eclub.bukujurnal.com/public/api/versi3/login?X-API-KEY=doran_data";
  final response = await http.post(url,body: {"username": emailcontroller.text , "password": passcontroller.text,}); 
  final  res = json.decode(response.body);
  print(res);

   
      if(res["result"] == true){
        Provider.of<Restapi>(context, listen: false).setuser(User.fromJson(res["data"]["profile"]));
          Navigator.pushNamed(context,'/Beranda');
      } else{
        print("login gagal");
      }
      
 
   
   
   
   }
 
  


var emailcontroller=new TextEditingController();
var passcontroller=new TextEditingController();
var emailinputcontroller=new TextEditingController();
var passinputcontroller=new TextEditingController();