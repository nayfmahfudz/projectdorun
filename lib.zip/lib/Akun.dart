import 'package:flutter/material.dart';
import 'model/User.dart';
import 'model/apirequest.dart';
import 'provider/Restapi.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';

class Akun extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final restapi = Provider.of<Restapi>(context);
    return Container(
      width: 325,
      height: MediaQuery.of(context).size.height,
      child: Drawer(
        child: ListView(
          children: <Widget>[
            // CachedNetworkImage(
            //   fit: BoxFit.contain,
            //   width: 30,
            //   height: 30,
            //   imageUrl: restapi.getuser().image.toString(),
            //   imageBuilder: (context, imageProvider) => Container(
                
            //     decoration: BoxDecoration(
                  
            //       image: DecorationImage(
            //           image: imageProvider,
            //           fit: BoxFit.cover,
            //           colorFilter:
            //               ColorFilter.mode(Colors.red, BlendMode.colorBurn)),
            //     ),
            //   ),
            //   placeholder: (context, url) => CircularProgressIndicator(),
            //   errorWidget: (context, url, error) => Icon(Icons.error),
            // ),
            Image.network(
          'https://picsum.photos/250?image=9',
          
        ),
            Text(restapi.getuser().nama),
            ListTile(
              title: Text(
                "Setting",
              ),
              contentPadding: EdgeInsets.all(4),
              // onTap: ,
              trailing: Icon(Icons.settings),
            ),
            ListTile(
              title: Text(
                "History",
              ),
              contentPadding: EdgeInsets.all(4),
              // onTap: ,
              trailing: Icon(Icons.history),
            ),
          ],
        ),
      ),
    );
  }
}
