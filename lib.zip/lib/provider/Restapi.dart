import 'package:flutter/material.dart';
import 'package:test2/model/User.dart';
import 'package:test2/model/berita.dart';

// class Restapi with ChangeNotifier{
//   List<Loginapi> _login;
//   List<Loginapi>  getlistlogin() => _login;

//   void setlistlogin(List<Loginapi> val){
//     _login = val;
//     notifyListeners();
//   }


  class Restapi with ChangeNotifier{
  User user;
  getuser() => user;

  void setuser(User val){
    user = val;
    notifyListeners();
  }

  List<Berita> beritas=[];
  // getberitauser() => berita;
  
  
  
  
  getberitas() =>beritas;  
  // void addCustomer(Customer customer) {  
  //   beritas.add(customer);  
  //   notifyListeners(); // Notify all it's listeners about update. If you comment this line then you will see that new added items will not be reflected in the list.  
  // }  
  

  void setberitauser(List<Berita> val){
    beritas = val;
    // beritas.add(val) ;
    notifyListeners();
  }

  
}
