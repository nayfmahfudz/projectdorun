import 'package:flutter/material.dart';
import 'package:test2/model/apirequest.dart';
import 'home.dart';
import 'Login.dart';
import 'Detail.dart';
import 'form.dart';
import 'package:provider/provider.dart';
import 'provider/Restapi.dart';

void main() => runApp(MyApp());



class MyApp extends StatelessWidget {
  final navigatorKey = GlobalKey<NavigatorState>();
  // This widget is the root of your application.
   final _rute= <String, WidgetBuilder>{
    '/Login': (context,) => Login(),
    '/Beranda': (context) => Home(),
    // '/Detail' : (context) => Detail(),'
    '/Form' : (context) => FormBio(),
  };
  @override
  Widget build(BuildContext context) {
    return MultiProvider(providers: [
        // ChangeNotifierProvider()
        // ChangeNotifierProvider<Restapi>(create: : (contex) => ()),
        ChangeNotifierProvider<Restapi>(
          create: (context) => Restapi(),)
    ],child:
      MaterialApp(
        navigatorKey: navigatorKey,
      title: 'DO(run)',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Login(),
      routes: _rute,
    ));
  }
}




