import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'model/apirequest.dart' ;
// import 'form.dart' ;
import 'main.dart';
import 'provider/Restapi.dart';


class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  

  @override
  Widget build(BuildContext context) {
    // final _formKey = GlobalKey<FormState>();
  final Restapi restapi = Provider.of<Restapi>(context);
  // restapi.getuser;
  // print("${restapi.listlogin[1].data.}");
  final email = TextFormField(
      controller: emailcontroller,
      keyboardType: TextInputType.emailAddress,
      autofocus: false,
      // initialValue: "Masukan Username atau Email",
      decoration: InputDecoration(
        hintText: 'Email',
        contentPadding: EdgeInsets.all(20),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
      ),
    );

    final password = TextFormField(
      validator: (String value){
        
      },
      controller: passcontroller,
      autofocus: false,
      obscureText: true,
      decoration: InputDecoration(
        hintText: ' Password',
        contentPadding: EdgeInsets.all(20),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
      ),
    );

    final loginButton = Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: Material(
        borderRadius: BorderRadius.circular(60.0),
        shadowColor: Colors.lightBlueAccent,
        // elevation: 5.0,
        child: MaterialButton(
          minWidth: 200.0,
          height: 42.0,
          onPressed: () {
            getuser(context);
            
            // Navigator.pushNamed(context,'/Beranda');
          },
          color: Colors.lightBlueAccent,
          child: Text('Log In', style: TextStyle(color: Colors.white)),
        ),
      ),
    );

    final belum = FlatButton(
      child: Text(
        'Belum punya akun?',
        style: TextStyle(color: Colors.black54),
      ),
      onPressed: () {
        
        Navigator.pushNamed(context,'/Form');
      },
    );
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.only(left: 24.0, right: 24.0),
          children: <Widget>[
            email,
            SizedBox(height: 8.0),
            password,
            SizedBox(height: 24.0),
            loginButton,
            SizedBox(height: 8.0),
            belum,
            
            // forgotLabel
          ],
        )
        ),
      
    );
  }
}