import 'package:flutter/material.dart';
import 'Detail.dart';
import 'package:page_transition/page_transition.dart';

class HalamanKedua extends StatelessWidget {
  // final List event = [1, 2, 3,4,5,6];
  final List<Map<String, dynamic>> event = [
    {'index':1,'title' : 'jackthon','status':'Succes','hari':'2020-06-20','terdaftar':'5','color': Colors.black},
    {'index':2,'title' : 'sidoarjo run','status':'Succes','hari':'2020-06-20','terdaftar':'5','color': Colors.white},
    {'index':3,'title' : 'bali fest','status':'Succes','hari':'2020-06-20','terdaftar':'5','color': Colors.white},
    {'index':4,'title' : 'tni run','status':'Succes','hari':'2020-06-20','terdaftar':'5','color': Colors.white},
    {'index':5,'title' : 'palembang ','status':'Succes','hari':'2020-06-20','terdaftar':'5','color': Colors.white},
    {'index':6,'title' : 'surockthon','status':'pending','hari':'2020-06-20','terdaftar':'5','color': Colors.white},
  ];
  Widget build(BuildContext context) {
    return SingleChildScrollView(child:Container( child:
    Column(
      
      children: <Widget>[
          Container(
            width: MediaQuery.of(context).size.width * 1,
            height: MediaQuery.of(context).size.height * 0.1,
            padding: EdgeInsets.all(5),
            // alignment: Alignment.topLeft,
            child: Text("Promosi",style: TextStyle(fontSize: 40),),
          ),

           Container(
              
              child: ListView.builder(
                physics: ScrollPhysics(),
                shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  itemCount: event.length,
                  itemBuilder: (context, index) => GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (contex)=>Detail(event)));
                    },
                    child:Hero(tag: event[index]['index'], 
                    child:
                    Container(
                    
                      width: MediaQuery.of(context).size.width * 0.8,
                      height: MediaQuery.of(context).size.height * 0.30,
                      child: Card(
                        color: Colors.black,
                        margin: EdgeInsets.all(5),
                        child: Container(
                          child: Center(
                              child: Text(
                            event[index]['title'].toString(),
                            style: TextStyle(color: Colors.white ,fontSize: 36.0),
                          )),
                        ),
                      )))))),
        
      ],
    )));
  }
}
