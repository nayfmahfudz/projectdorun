import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'provider/Restapi.dart';
import 'model/apirequest.dart';
import 'model/apirequest.dart';

class Event extends StatelessWidget {
  
 
  @override
  Widget build(BuildContext context) {
    final restapi =Provider.of<Restapi>(context);
    //  List _event = [1, 2, 3];
    // getberita();
    int index;
    return  Container(
      margin: EdgeInsets.all(5),
        height: MediaQuery.of(context).size.height * 0.45,
        width: MediaQuery.of(context).size.width ,
        child:FutureBuilder(
          future: getberita(),
          builder: (context,snapshot) {
          if (snapshot.hasData){
            print(snapshot.data);
          return ListView.builder(
            
            scrollDirection: Axis.horizontal,
            itemCount: snapshot.data.length,
            itemBuilder: (context, index) => Container(
      margin: EdgeInsets.all(5),
        height: MediaQuery.of(context).size.height * 0.45,
        // width: MediaQuery.of(context).size.width ,ss
        child:Column(children:[
              Expanded(flex: 8,
                child:
                Container(
                width: MediaQuery.of(context).size.width * 0.8,
                child: Card(
                  color: Colors.black,
                  margin: EdgeInsets.all(5),
                  shape: RoundedRectangleBorder(
                    // borderRadius: BorderRadius.circular(30),
                  ),
                  child: Container(
                    child: Center(
                        child: Text(
                      snapshot.data[index]["nama"],
                      style: TextStyle(color: Colors.white, fontSize: 36.0),
                    )),
                  ),),),),
                  Expanded(
                    flex: 2,
                    child:
                  Container(
                    padding: EdgeInsets.fromLTRB(3, 3, 3, 10),
                  child:Row(
                    children: <Widget>[
                      
                      Container(
                        alignment: Alignment.centerLeft,
                        padding: EdgeInsets.only(right: 20,left: 30),
                        child:
                      Column(

                        children: <Widget>[
                          
                          Text("5",textAlign: TextAlign.left,style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),),
                        
                          Text("may",textAlign: TextAlign.left, style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),),
                        ],

                      ),),
                      
                      // Align( 
                      //   alignment: Alignment.centerLeft,
                      //   child:
                      Container(
                        padding: EdgeInsets.only(right: 180),
                        child:
                      Column(
                        children: <Widget>[
                          Text("Marathon 5k Run",textAlign: TextAlign.left,style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),),
                          Text("jakarta",textAlign: TextAlign.left,style: TextStyle(fontWeight: FontWeight.bold,color: Colors.black),),
                        ],

                      ),)
                    ],

                  )

                )
          

          )
          ]
          )
          )
          
          );
          } else if (snapshot.hasError) {
          return new Text("${snapshot.error}");
        }
        return new CircularProgressIndicator();
      } 
          ));
          
  }
}
