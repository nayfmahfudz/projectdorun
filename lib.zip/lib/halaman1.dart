import 'package:flutter/material.dart';
import 'Category.dart';
import 'Event.dart';
import 'Merchant.dart';
import 'provider/Restapi.dart';
import 'package:provider/provider.dart';


class HalamanPertama extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final restapi =Provider.of<Restapi>(context);
    return 
    SingleChildScrollView(
      child:Stack(
      children:[
        Positioned(child: 
        Container(
          color: Colors.red,
          width: MediaQuery.of(context).size.width
        ),),
      Container(
      color: Colors.white,
      padding: EdgeInsets.all(20),
      child: Column(
        children: <Widget>[
          Align(alignment: Alignment.centerLeft, child:  Text("News",style: TextStyle(fontSize: 35,color:Colors.blueAccent),),),
          Event(),
          Align(alignment: Alignment.centerLeft, child:  Text("Category",style: TextStyle(fontSize: 35,color:Colors.blueAccent),),),
          Category(),
          Align(alignment: Alignment.centerLeft, child:  Text("Merchant",style: TextStyle(fontSize: 35,color:Colors.blueAccent),),),
          Merchant(),
        ],
      ),
    )]));
}}