import 'package:flutter/material.dart';
import 'Akun.dart';
import 'halaman1.dart'  ;
import 'halaman2.dart' ;
import 'halaman3.dart'  ;
import 'halaman4.dart' ;
import 'Halamankelima.dart';
import 'model/apirequest.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with TickerProviderStateMixin {
    TabController controller;

  @override

  void initState(){
    controller = new TabController(vsync: this, length: 5);
    //tambahkan SingleTickerProviderStateMikin pada class _HomeState
    super.initState();
  }

  @override
  void dispose(){
    controller.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    // getberita();
    return Scaffold(drawer:Akun(),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.blueAccent,
          title: Text("Do(Run)",textAlign: TextAlign.center,),
        ),
        body: 
            // DefaultTabController(length: 4, child:
            TabBarView(
              controller: controller,
              children:[ 
            
             HalamanPertama(),
             HalamanKedua(),
             HalamanKetiga(),
             Halamankelima(),
             HalamanKeempat(),
             
            ]

        ),
      // ),
      bottomNavigationBar:Material(
        color: Colors.blueAccent,
          child:TabBar(
            labelPadding: EdgeInsets.all(1),
             controller: controller,
             tabs: <Widget>[
               Tab(icon:  Icon(Icons.home),text: "Home",),
               Tab(icon:  Icon(Icons.list),text: "Event",),
               Tab(icon:  Icon(Icons.schedule),text: "Jadwal",),
               Tab(icon:  Icon(Icons.redeem),text: "Reward",),
               Tab(icon:  Icon(Icons.account_circle),text: "Akun",),
             ],
          ),
      
      // onTap: ,

        
      
    ));
    
  }
}


// class Home extends StatelessWidget with TickerProviderStateMixin {
//   @override
  
//   Widget build(BuildContext context) {
//     return 
//   }
// }