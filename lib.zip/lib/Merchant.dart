import 'package:flutter/material.dart';


class Merchant extends StatelessWidget {
  final List event =[1111111111,2222222,33333333333,44444444,555555555,66666666666666,7777777777777];
  @override
  Widget build(BuildContext context) {
    
    return Container(height: 150,
    width: MediaQuery.of(context).size.width,
    // margin: EdgeInsets.all(3),
    // padding: EdgeInsets.all(3),
      child:ListView.builder(
            physics: ScrollPhysics(),
            padding: EdgeInsets.all(10),
            shrinkWrap: true,
            itemExtent: 103,
            scrollDirection: Axis.horizontal,
            itemCount: event.length,
            itemBuilder: (context, index) {
              return
        Row(    
      children: <Widget>[
      Container( 
         
        child: Column(children:[
        
        // color: Colors.red,
        Container( 
         
        height: 100,
        width: 100,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.red
          
        ),
        
        ),
        Text(event[index].toString()),
        ])

        // CircleAvatar(
        //   radius: 30,
        //   backgroundColor: Colors.red,
        //   child: Text(_event[index].toString()),
        // )
    )]);}));
      
      
  }
}