import 'package:flutter/material.dart';

class Category extends StatelessWidget {
  
  @override
  
  final List<Map<String, dynamic>> _category = [
    {'cat': '5K', 'color': Colors.pink},
    {'cat': '10K', 'color': Colors.blue},
    {'cat': 'HALF', 'color': Colors.amber},
    {'cat': 'FULL', 'color': Colors.yellow},
    {'cat': 'KID', 'color': Colors.red},
    
  ];
 
  Widget build(BuildContext context) {
    return Container(
        margin: const EdgeInsets.all(10.0),
        child: GridView.builder(
          physics: ScrollPhysics(),
          shrinkWrap: true,
          itemCount: _category.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              
              childAspectRatio: 1),
          itemBuilder: (context, index) {
            return  Container(
                color: _category[index]['color'],
                height: 200,
                child: Container(
                  alignment: Alignment.topLeft,
                  child: Text(
                    _category[index]['cat'],
                    style: TextStyle(
                      color: _category[index]['cat'] != 'Javascript'
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 30,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
              );
          }));
    
  }
}


// class Listgridview {
// String warna;
// Image gambar;
// Text teks;
//   Listgridview(this.gambar,this.teks,this.warna);
// }


  

  
