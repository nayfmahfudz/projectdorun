import 'dart:ui';
import 'package:flutter/material.dart';

String urldasar='https://klomee.gempikoe.co.id/public/api/';

Color colordefault = Color.fromRGBO(233, 165, 176, 1);

String kode_apk="id.klomee.gempikoe";