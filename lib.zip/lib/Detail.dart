import 'package:flutter/material.dart';
import 'Category.dart';

class Detail extends StatelessWidget {
  Detail(this.event);
  final List event;
  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
     appBar: AppBar(
       title: Text("Another Screen"),
       backgroundColor: Colors.blue,
     ),
     body:
         Column(
             children: <Widget>[
                // Align(
      // alignment: Alignment.bottomCenter,
      // child:
      //    RaisedButton(
           
      //      child: Text("join"),
      //      color: Colors.blueAccent,
      //            onPressed: (){},
  
      //     ), ),
    //  CustomScrollView(
	
    //         slivers: <Widget>[
	
    //           SliverAppBar(
	
    //             leading: IconButton(
	
    //               icon: Icon(Icons.local_hotel),
	
    //               onPressed: () {
	
    //                 // Do something
	
    //               }
	
    //             ),
	
    //             expandedHeight: 220.0,
	
    //             floating: true,
	
    //             pinned: true,
	
    //             snap: true,
	
    //             elevation: 50,
	
    //             backgroundColor: Colors.red,
	
    //             flexibleSpace: FlexibleSpaceBar(
	
    //                 centerTitle: true,
	
    //                 title: Text('Beautiful Women',
	
    //                     style: TextStyle(
	
    //                       color: Colors.white,
	
    //                       fontSize: 16.0,
	
    //                     )),
	
    //                 background: Image.network(
	
    //                   'https://images.pexels.com/photos/638700/pexels-photo-638700.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
	
    //                   fit: BoxFit.cover,
	
    //                 )
	
    //             ),
	
    //           ),
	
    //           new SliverList(
	
    //               delegate: new SliverChildBuilderDelegate(event)=>
	
            
	
     ListView.builder(
        //  padding:  EdgeInsets.all(8.0),
          itemExtent: 106.0,
          physics: ScrollPhysics(),
          shrinkWrap: true,
          // itemCount: event.length,
          itemBuilder: (context, index)=>
       
        Hero(
         tag: event[index]['index'],
         child:  Container(child:
         Column(
             children: <Widget>[
         Container(
           width: MediaQuery.of(context).size.width,
           height: MediaQuery.of(context).size.height/2,
           decoration: BoxDecoration(color: event[index]['color']),
           child: Column(
             children: <Widget>[
               Text("DESKRIPSI"),
               
               

             ],
           ),

         ),
        ]),

	
     
	
          )))]));
  
  }
}