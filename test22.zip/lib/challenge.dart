import 'package:flutter/material.dart';

class Challenge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("challenge masih kosong",textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 40)),
      
    );
  }
}